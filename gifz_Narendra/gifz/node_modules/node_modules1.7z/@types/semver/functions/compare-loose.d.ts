import SemVer = require("../classes/semver");

declare function compareLoose(v1: string | SemVer, v2: string | SemVer): 1 | 0 | -1;

export = compareLoose;
