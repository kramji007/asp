# Installation
> `npm install --save @types/serve-static`

# Summary
This package contains type definitions for serve-static (https://github.com/expressjs/serve-static).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/serve-static.

### Additional Details
 * Last updated: Mon, 25 Sep 2023 13:39:06 GMT
 * Dependencies: [@types/http-errors](https://npmjs.com/package/@types/http-errors), [@types/mime](https://npmjs.com/package/@types/mime), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Uros Smolnik](https://github.com/urossmolnik), [Linus Unnebäck](https://github.com/LinusU), and [Devansh Jethmalani](https://github.com/devanshj).
