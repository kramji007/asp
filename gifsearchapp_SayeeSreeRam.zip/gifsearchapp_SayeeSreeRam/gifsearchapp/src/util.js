export const apiKey = "sNP2j3cum5Nm7ACUWpf30XvhqRW8gYi4";
export const trendingEndpoint = "https://api.giphy.com/v1/gifs/trending";
export const searchingEndPoint = "https://api.giphy.com/v1/gifs/search";