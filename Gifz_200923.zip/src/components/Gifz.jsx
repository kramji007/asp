import React, { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./gifz.css";

const API_KEY = "Ep801vJUuwbdBmn8lq5eXOYNwEB3BqUq";

const Gifz = () => {
  const navigate = useNavigate();
  const loadMoreRef = useRef();
  const [searchTerm, setSearchTerm] = useState("");
  const [gifs, setGifs] = useState([]);
  const [loadMore, setLoadMore] = useState(0);

  const fetchData = useCallback((apikey, searchTerm, loadMore) => {
    axios
      .get(
        `https://api.giphy.com/v1/gifs/search?api_key=${apikey}&q=${searchTerm}&limit=20&offset=${loadMore}`
      )
      .then((res) => {
        setGifs((prev) => [...prev, ...res.data.data]);
      })
      .catch((err) => {
        console.error("Error: ", err);
      });
  }, []);

  useEffect(() => {
    fetchData(API_KEY, searchTerm, loadMore);
  }, [loadMore, fetchData]);

  const handleSearch = (e) => {
    e.preventDefault();
    fetchData(API_KEY, searchTerm, loadMore);
  };

  const handleLoadMore = () => {
    setLoadMore((prev) => prev + 10);
  };

  const handleObserver = useCallback((entries) => {
    const target = entries[0];
    if (target.isIntersecting) {
      setLoadMore((prev) => prev + 10);
    }
  }, []);

  useEffect(() => {
    const option = {
      root: null,
      rootMargin: "20px",
      threshold: 0,
    };
    const observer = new IntersectionObserver(handleObserver, option);
    if (loadMoreRef.current) observer.observe(loadMoreRef.current);
  }, [handleObserver]);

  return (
    <React.Fragment>
      <div className="container">
        <div className="header">
          <form onSubmit={handleSearch}>
            <label>Search your gifs : </label>
            <input
              type="text"
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Enter search and press enter"
            />

            <button
              className="primary_btn"
              type="button"
              onClick={() => {
                navigate("/trendings");
              }}
            >
              Trendings
            </button>
          </form>
        </div>

        <div className="content">
          <div className="content_body">
            {gifs.length > 0 &&
              gifs.map((g) => (
                <div key={g.id} className="gif_card">
                  <iframe title={g.title} src={g.embed_url} alt={g.title} />
                </div>
              ))}
          </div>
          <div className="footer_btn_section" ref={loadMoreRef}>
            {gifs.length > 0 && (
              <button
                className="secondary_btn"
                type="button"
                onClick={handleLoadMore}
              >
                Stay tuned, the page will auto-load more items soon.
              </button>
            )}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Gifz;
