import { Fragment, useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./gifz.css";

const Trendings = () => {
  const navigate = useNavigate();
  const containerRef = useRef();
  const loaderRef = useRef();
  const [trendingList, setTrendingList] = useState([]);
  const [loadMore, setLoadMore] = useState(0);

  const fetchData = async () => {
    const response = await axios.get(
      `https://api.giphy.com/v1/gifs/trending?api_key=Ep801vJUuwbdBmn8lq5eXOYNwEB3BqUq&limit=20&offset=${loadMore}&rating=g&bundle=messaging_non_clips`
    );
    setTrendingList((prev) => [...prev, ...response.data.data]);
  };

  useEffect(() => {
    console.log("useeffect is called for loadmore change");
    fetchData();
  }, [loadMore]);

  const handleLoadMore = () => {
    setLoadMore((prev) => prev + 10);
  };

  const handleObserver = useCallback((entries) => {
    const target = entries[0];
    if (target.isIntersecting) {
      setLoadMore((prev) => prev + 10);
    }
  }, []);

  useEffect(() => {
    const option = {
      root: null,
      rootMargin: "20px",
      threshold: 0,
    };
    const observer = new IntersectionObserver(handleObserver, option);
    if (loaderRef.current) observer.observe(loaderRef.current);
  }, [handleObserver]);

  return (
    <Fragment>
      <div className="container" ref={containerRef}>
        <button
          type="button"
          onClick={() => {
            navigate("/");
          }}
        >
          {"<"} Go back
        </button>
        <div className="trending_header">Trendings</div>
        <div className="content">
          <div className="content_body">
            {trendingList.length > 0 &&
              trendingList.map((g) => (
                <div key={g.id} className="gif_card">
                  <iframe title={g.title} src={g.embed_url} alt={g.title} />
                </div>
              ))}
          </div>
          <div className="footer_btn_section" ref={loaderRef}>
            <button
              className="secondary_btn"
              type="button"
              onClick={handleLoadMore}
            >
              Stay tuned, the page will auto-load more items soon.
            </button>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default Trendings;
