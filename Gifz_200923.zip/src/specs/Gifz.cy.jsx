import cy from "cypress";
// cypress/integration/gifz.spec.js

describe("Gifz Component", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("should load gifs on search", () => {
    cy.get("input[type='text']").type("cats{enter}");
    cy.get(".gif_card").should("have.length.gt", 0);
  });

  it("should load more gifs when 'Load more' is clicked", () => {
    cy.get("input[type='text']").type("dogs{enter}");
    cy.get(".gif_card").should("have.length.gt", 0);

    cy.get(".footer_btn_section")
      .contains("Stay tuned, the page will auto-load more items soon.")
      .click();
    cy.get(".gif_card").should("have.length.gt", 10);
  });

  it("should navigate to '/trendings' when 'Trendings' button is clicked", () => {
    cy.get("button.primary_btn").click();
    cy.url().should("include", "/trendings");
  });
});
