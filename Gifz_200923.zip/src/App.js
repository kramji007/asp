import { BrowserRouter, Routes, Route } from "react-router-dom";
import Gifz from "./components/Gifz";
import Trendings from "./components/Trendings";
import "./App.css";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Gifz />} />
        <Route path="/trendings" element={<Trendings />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
