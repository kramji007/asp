describe('Trendings.cy.jsx', () => {
  it('playground', () => {
    // cy.mount()
  })
})